# FXL ESPORTS: existing site + contact backend (no Next.js, no build step)
- index.html : your existing site (only the Contact form script changed)
- admin.html : admin inbox at /admin.html
- api/*.js   : serverless backend (Vercel). Secrets live only here, as environment variables.
- supabase/schema.sql : run once in Supabase SQL Editor
Deploy: put this folder in a GitHub repo, import it in Vercel (Framework: Other, no build command), add the 4 variables from .env.example in Vercel > Settings > Environment Variables, deploy.
